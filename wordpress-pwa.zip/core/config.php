<?php

define("WMP_VERSION", '1.0');
define('WMP_PLUGIN_NAME', 'PT PWA');
define('WMP_DOMAIN', 'wordpress-pwa');

define('WMP_PLUGIN_PATH', WP_PLUGIN_DIR . '/'.WMP_DOMAIN.'/');

define('WMP_APPTICLES_TRACKING_SSL','https://api.appticles.com/content1/wptracking');

?>
