<?php

define("PWA_VERSION", '1.0');
define('PWA_PLUGIN_NAME', 'PT PWA');
define('PWA_DOMAIN', 'wordpress-pwa');
define('PWA_PLUGIN_PATH', WP_PLUGIN_DIR . '/'.PWA_DOMAIN.'/');

?>
