<?php

namespace Zumba\Exception;

use RuntimeException;

/**
 *
 * @deprecated Will be removed on the 3.0.0. Use Zumba\JsonSerializer\Exception\JsonSerializerException instead
 */
class JsonSerializerException extends RuntimeException
{
}
