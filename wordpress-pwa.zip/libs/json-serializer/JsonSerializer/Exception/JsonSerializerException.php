<?php

namespace Zumba\JsonSerializer\Exception;

use Zumba\Exception\JsonSerializerException as OriginalException;

class JsonSerializerException extends OriginalException
{
}
