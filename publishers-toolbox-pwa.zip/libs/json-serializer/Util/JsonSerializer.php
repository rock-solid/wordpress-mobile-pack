<?php

namespace Zumba\Util;

use Zumba\JsonSerializer\JsonSerializer as NewJsonSerializer;

/**
 *
 * @deprecated Will be removed on the 3.0.0. Use Zumba\JsonSerializer\JsonSerializer instead
 */
class JsonSerializer extends NewJsonSerializer
{
}
