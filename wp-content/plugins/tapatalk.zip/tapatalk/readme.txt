=== Tapatalk for WordPress ===
Contributors: Tapatalk
Tags: Tapatalk, mobile, forum, iPhone, Android, iOS, phpBB, vBulletin, SMF, IPBoard, XenForo, MyBB, Kunena
Donate link: http://www.worldvision.org
Requires at least: 3.3
Tested up to: 3.9.0
Stable tag: 1.0.2
License: MIT License
License URI: http://opensource.org/licenses/MIT

Tapatalk for WordPress Plugin enables Tapatalk Community Reader to integrate WordPress Blogs and Forums into a single mobile app.

== Description ==

Tapatalk for WordPress is an extension to your existing Tapatalk installation, enable you to add WordPress-powered content into the Tapatalk Community Reader mobile app. Tapatalk is an end-to-end mobile solution for your website that combine content and discussions into a single mobile app. Over 60000 websites have installed and activated Tapatalk.

Interested to learn more? Download our mobile app or visit our website at http://tapatalk.com

= Features include: =

* JSON API to fetch latest WordPress Blogs

== Installation ==

1. Install from either the WordPress.org Plugin Directory, or by manually uploading the files to your server
2. Activate the Plugin from the 'Plugins' menu in WordPress Admin Console
3. Login to Tapatalk Forum Owner Area (tapatalk.com) to enable WordPress module by entering your WordPress top level URL
4. The Blogs will appear on Tapatalk app within 24 hours, usually in next app restart.

== Frequently Asked Questions ==

= Who should install this plugin? =

Website who has Tapatalk activated for the community/forums

= I don't have a forum / community, can I still use Tapatalk for WordPress =

Not at the moment, but we have plan to make it standalone

= Why do I need a mobile app while WordPress has provide fantastic support for mobile web? =

Because people love to have choice ;) Your forum users can immediate consume your latest blogs and article within a single app, isn't that nice?

== Screenshots ==
1. screenshot 1
2. screenshot 2
3. screenshot 3

== Changelog ==

= 1.0.2 =

fix some bugs

== Upgrade Notice ==

Developed and Tested on WordPress version 3.3 or higher. However it should work with older versions also.