<?php
	require_once('template.php');// load app
?>