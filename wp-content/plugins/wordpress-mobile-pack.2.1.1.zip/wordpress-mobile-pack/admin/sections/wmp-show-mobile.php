<div id="show-mobile" style="width:100%; text-align: center;">
	<a href="<?php echo get_bloginfo('url');?>?wmp_theme_mode=mobile" title="Switch to mobile version">Switch to mobile version</a>
</div>